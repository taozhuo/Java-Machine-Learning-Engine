import java.util.*;


public class Sample {

	public List<Double> features;
	public int category;
	Sample(List<Double> l, int c)
	{
		features=l;
		category=c;
	}
	
	public static void main(String[] args) {
		

	}

}
