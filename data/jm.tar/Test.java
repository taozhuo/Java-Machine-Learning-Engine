import java.util.*;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//List<Double> l=new ArrayList<Double>();
	//	Dataset d=new Dataset(args[0]);
		

	}

}
